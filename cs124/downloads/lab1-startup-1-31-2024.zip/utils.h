#pragma once
void getCurrentTime(int& mo, int& d, int& yr, int& hr, int& min, int& sec);