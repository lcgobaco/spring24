/**
* Name: <your name>
* Description: provide a short description of this class
* Date: <2/10/2024>
*/

#include <iostream>
#include <sstream>
#include <string>

#include "userMenu.h"
#include "utils.h"

using namespace std;

/**
* TODO: provide comment here
*/
UserMenu::UserMenu() 
	: Menu("Manage User Accounts") {

	// init usermenu options
	initSelection();
	// load users_data.csv
	initData();
}

/**
* TODO: provide comment here
*/
UserMenu::UserMenu(string name)
	: Menu(name) {

	// init usermenu options
	initSelection();
	// load users_data.csv
	initData();
}

/**
* List the usermenu selection...
*/
void UserMenu::initSelection() {
	// Initialize users options
	addOption("1) Sign-in");
	addOption("2) Sign Out");
	addOption("3) Reset Password");
	addOption("4) Create Account");
	addOption("5) Manage Profiles");
	addOption("x) Quit");
}

/**
* TODO: provide comment here
*/
void UserMenu::initData() {
	openFile(inFile, USER_DATA);

	if (!inFile) {// Returns error if file error occurs
		cout << "Error opening file: " << USER_DATA << std::endl;
		return;
	}

	string line, text;
	int id = 0;
	string role, username, password, signInText, signOutText, fName, lName, address, city, state, zip, phone, email;

	int count = 0;
	while (getline(inFile, line)) {
		// Skip the first line - column names
		if (++count == 1) {
			continue;
		}
		istringstream ss(line);
		getline(ss, text, ',');
		id = stoi(text); // convert from text string to integer
		getline(ss, role, ',');
		getline(ss, username, ',');
		getline(ss, password, ',');
		getline(ss, signInText, ',');
		getline(ss, signOutText, ',');
		getline(ss, fName, ',');
		getline(ss, lName, ',');
		getline(ss, address, ',');
		getline(ss, city, ',');
		getline(ss, state, ',');
		getline(ss, zip, ',');
		getline(ss, phone, ',');
		getline(ss, email, ',');
		User user;
		user.setId(id);
		user.setRole(role);
		user.setSignInDateTime(signInText);
		user.setSignOutDateTime(signInText);
		user.setUserName(username);
		user.setPassword(password);
		user.setFirstName(fName);
		user.setLastName(lName);
		user.setAddress(address);
		user.setCity(city);
		user.setState(state);
		user.setZip(zip);
		user.setPhone(phone);
		user.setEmail(email);
		list.push_back(user);
	}

	inFile.close();
}

/**
* TODO: provide comment here
*/
void UserMenu::activate() {
	char input = 0;
	do {
		input = this->doMenuOption();
		if (input == USER_MENU_SIGNIN) {
			signIn();
		}
		else if (input == USER_MENU_SIGNOUT) {
			signOut();
		}
		else if (input == USER_MENU_RESET) {
			reset();
		}
		else if (input == USER_MENU_CREATE) {
			create();
		}
		else if (input == USERMENU_MANAGE_PROFILE) {
			manageProfiles();
		}
		else if (input == USER_MENU_EXIT) {
			doExit();
		}
		else {
			cout << "Invalid selection!!!" << endl;
		}
	} while (input != USER_MENU_EXIT);

}

/**
* TODO: provide comment here
*/
bool UserMenu::authenicate(string name, string pwd) {
	bool valid = false;
	for (int i = 0; i < list.size() /** vector of users */; i++) {
		User u = list.at(i);
		// User the overloading operators for Week 3 in-class
		if ((name == u.getUsername() || name == u.getEmail()) && pwd == u.getPassword()) {
			valid = true;
			break;
		}
	}
	return valid;
}

/**
* TODO: provide comment here
*/
void UserMenu::signIn() {
	cout << "Sign-in" << endl;
	cout << "Enter email or mobile phone number: ";
	string name;
	cin >> name; // check if username or email (i.e. @)
	cout << "Enter password: ";
	string pwd;
	cin >> pwd;
	
	loginIn = authenicate(name, pwd);
	if (loginIn) {
		// System datetime now and update sign in datetime
		int mo, d, yr, hr, min, sec;
		getCurrentTime(mo, d, yr, hr, min, sec);
	}
	else {
		cout << "Invalid username or password" << endl;
	}
}

/**
* TODO: provide comment here
*/
void UserMenu::signOut() {
	cout << "TODO Handle sign-Out" << endl;
	// User must be already sign - in
	if (loginIn) {
		// Update sign out datetime
		// Save new sign - in and sign - out datetime to users_data.csv
	} else {
		cout << "You must sign-in before proceed" << endl;
		signIn();
	}
}

/**
* TODO: provide comment here
*/
void UserMenu::reset() {
	cout << "TODO Handle reset password" << endl;
	// Reset Password
	// User must be already sign - in
	// Enter old password
	// Enter new password
	// Save new password to users_data.csv
}

/**
* TODO: provide comment here
*/
void UserMenu::create() {
	cout << "TODO Handle create new user" << endl;
	// Enter first and last name
	// Enter mobile number or email
	// Enter password
	// Enter re - enter password
	// Forgot your password ? Only role = admin can reset your password.
	// Save new sign - in, sign - out datetime, and data to users_data.csv

}

/**
* TODO: provide comment here
*/
void UserMenu::manageProfiles() {
	cout << "TODO Handle manage profiles" << endl;
	// User must be already sign - in
	// Allow user to change(update or delete) personal information, name, role, address, phone, email
	// Save new data to users_data.csv
}

/**
* TODO: provide comment here
*/
void UserMenu::doExit() {
	cout << "TODO Handle exit" << endl;
	// Enter char 'x' to exit Sign Out and update sign out datetime.
}

/**
* TODO: provide comment here
*/
void UserMenu::saveData() {
	inFile << "Id, Role, Username, Password, Sign - in datetime, Sign out datetime, First Name, Last Name, Address, City, State, Zip, Phone, Email" << endl;
	for (User user : list){
		inFile << user << endl;
	}
}