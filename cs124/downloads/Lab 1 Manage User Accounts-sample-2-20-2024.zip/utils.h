/**
* Name: <your name>
* Description: Prototype of the general propose functions
* Date: <2/10/2024>
*/

#pragma once
#include <string>
#include <fstream>

using namespace std;

void getCurrentTime(int& mo, int& d, int& yr, int& hr, int& min, int& sec);

void openFile(fstream& inFile, string fileName);