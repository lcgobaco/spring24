/**
* Name: <your name>
* Description: provide a short description of this class
* Date: <2/10/2024>
*/
#include <iostream>
#include "user.h"

using namespace std;

/**
* TODO: provide comment here
*/
User::User() {
	id = 0;
}

/**
* TODO: provide comment here
*/
User::~User() {
	// TODO
}

/**
* TODO: provide comment here
*/
string User::to_csv() {
	return to_string(id) + ","
		+ role + ","
		+ username + ","
		+ password + ","
		+ signInDt.toString() + ","
		+ signOutDt.toString() + ","
		+ firstname + ","
		+ lastname + ","
		+ address + ","
		+ city + ","
		+ state + ","
		+ zip + ","
		+ phone + ","
		+ email;
}

/**
* TODO: provide comment here
*/
bool User::operator==(const User& user) const {
	return id == user.id;
}

/**
* TODO: provide comment here
*/
bool User::operator!=(const User& user) const {
	return id != user.id;
}

/**
* TODO: provide comment here
*/
bool User::operator>(const User& user) const {
	return id > user.id;
}

/**
* TODO: provide comment here
*/
bool User::operator<(const User& user) const {
	return id < user.id;
}

/**
* TODO: provide comment here
*/
bool User::operator>=(const User& user) const {
	return id >= user.id;
}

/**
* TODO: provide comment here
*/
bool User::operator<=(const User& user) const {
	return id <= user.id;
}

/**
* TODO: provide comment here
*/
istream& operator >>(istream& in, User& user){
	// TODO
	return in;
}

/**
* TODO: provide comment here
*/
ostream& operator<<(ostream& out, User& user) {
	out << user.to_csv();
	return out;
}
