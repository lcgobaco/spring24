/**
* Name: <your name>
* Description: <provide a short description of your program
* Date: <2/10/2024>
*/

#include "userMenu.h"
using namespace std;

int main() {
	UserMenu app;	// invoke the default constructor
	app.activate();	// Start the user menu selection
	return 0;
}