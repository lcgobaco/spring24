/**
* Name: <your name>
* Description: provide a short description of this class
* Date: <2/10/2024>
*/

#pragma once
#include <string>
#include "time.h"

using namespace std;


class DateTime : public Time {
	friend ostream& operator<<(ostream& out, DateTime dt);

public:
	DateTime();
	DateTime(string dt);
	DateTime(int mon, int day, int yr);
	DateTime(int mon, int day, int yr, int hr, int min, int second);

	void setDateTime(string dt);

	int getMonth() { return month; };
	int getDay() { return day; };
	int getYear() { return year; };

	string toString();

	// You may need these operators for comparing datetime
	bool operator>(const DateTime&) const;
	bool operator<(const DateTime&) const;
	bool operator>=(const DateTime&) const;
	bool operator<=(const DateTime&) const;

private:
	int month;
	int day;
	int year;
};
