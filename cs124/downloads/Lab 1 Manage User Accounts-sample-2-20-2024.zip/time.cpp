/**
* Name: <your name>
* Description: provide a short description of this class
* Date: <2/10/2024>
*/
#include <iostream>
#include <sstream>
#include <string>
#include <iomanip>
#include "time.h"

using namespace std;

/**
* TODO: provide comment here
*/
string Time::toString() {
	return to_string(hour) + ":" + to_string(minute) + ":" + to_string(second); // AM/PM or 24H
}

/**
* TODO: provide comment here
*/
void Time::setTime(string t) {
	// Parse string ".... 18:30:11" to hr, min, sec
	string text;
	istringstream ss2(t);
	getline(ss2, text, ':');
	int hr = stoi(text);
	getline(ss2, text, ':');
	int min = stoi(text);
	getline(ss2, text, ':');
	int second = stoi(text);
	setHour(hr);
	setMinute(min);
	setSecond(second);
}


/**
* TODO: provide comment here
* Time format hour:minute:second
*/
ostream& operator<<(ostream& out, Time time) {
	char fill = out.fill('0');
	out << setw(2) << time.hour << ':'
		<< setw(2) << time.minute << ':'
		<< setw(2) << time.second;
	out.fill(fill);
	return out;
}