#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

void loadCSV(const string filename) {

	ifstream file(filename);

	if (!file) {// Returns error if file error occurs

		cout << "Error opening file: " << filename << std::endl;
		return;
	}

	string line;
	int id;
	string first;
	while (getline(file, line)) {

		//istringstream ss(line);
		//ss >> id;

		//getline(ss, first, ',');
		cout << line << endl;
	}

	file.close();
}

int main() {
	loadCSV("users_data.csv");

	return 0;
}
