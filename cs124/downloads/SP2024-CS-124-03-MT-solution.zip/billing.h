#ifndef H_BILLTYPE
#define H_BILLTYPE
#include <iostream>
#include <istream>
#include <string>
#include "doctor.h"
#include "person.h"
#include "dateTime.h"

using namespace std;

class Billing {

    friend istream& operator >>(istream& in, Billing& b);
    friend ostream& operator<<(ostream& out, Billing& b);

public:
    // constructor
    Billing();
    Billing(int id = 0, double charges = 0, double rent = 0, double doctorFee = 0);

    void setId(int id);		        // set the patient ID
    void setPharmacy(double);		// add pharmacy charges
    void setRent(double);			// add room rent charges
    void setDoctorFee(double);		// add doctor's fee

 private:
    int id;                         // patient ID
    double pharmacyCharges;         // charges from pharmacy
    double roomRent;                // charges from rent
    double doctorFee;               // charges from doctor
};

#endif
