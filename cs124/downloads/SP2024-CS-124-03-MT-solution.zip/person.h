#pragma once
#include <iostream>
#include <istream>
#include <string>

using namespace std;

class Person {
	friend istream& operator >>(istream& in, Person& p);
	friend ostream& operator<<(ostream& out, Person& p);
public:
	Person(int id, string first = "", string last = "");
	void setId(int _id) { id = id; };
	void setFirst(string first);
	void setLast(string last);
	int getId() { return id; };
	string getFirstName();
	string getLastName();
	string getFullName() { return firstName + " " + lastName; };

protected:
	int id;				//id
	string firstName;	//variable to store the first name
	string lastName;	//variable to store the last name
};

