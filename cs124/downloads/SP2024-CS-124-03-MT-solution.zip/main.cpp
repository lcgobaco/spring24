#include <iostream>
#include <string>
#include "billingMenu.h"
using namespace std;

void banner();

int main() {
    banner();
    BillingMenu m;
    m.activate();

    return 0;
}
void banner() {
    cout << "*****************************************************" << endl;
    cout << "\tProgram written by : John Doe" << endl;
    cout << "\tDescription : The Hospital Billing System" << endl;
    cout << "\tCourse info : CS124 - 03" << endl;
    cout << "\tTerm : Fall 2024" << endl;
    cout << "\tDate : <show today date>" << endl;
    cout << "*****************************************************" << endl << endl;
}
