#ifndef DOCTORTYPE_H
#define DOCTORTYPE_H
#include <iostream>
#include <string>
#include <istream>
#include "person.h"

using namespace std;

class Doctor: public Person {

	friend istream& operator>>(istream& in, Doctor& d);
	friend ostream& operator<<(ostream& out, Doctor& d);

public:
	Doctor();
	Doctor(string first, string last, string specialty);
	void setSpecialty(string speciality) { this->speciality = speciality; }
	string getSpeciality() { return speciality; };
	void print();		// print doctor information

private:
    string speciality;		// Provide text description of the doctor speciality, ex. Internal
};


#endif // DOCTORTYPE_H
