#pragma once

#include "menu.h"
#include "linkedQueue.h"
#include "dateTime.h"
#include "person.h"
#include "billing.h"
#include "patient.h"
#include "menu.h"

using namespace std;

class BillingMenu : public Menu {
public:
	BillingMenu();
	void addPatient();
	void print();
	void activate();
private:
	LinkedQueue<Patient> list;
};