#include <iostream>
#include "person.h"

using namespace std;

// constructor
Person::Person(int id, string first, string last) { 
	this->id = id;
	firstName = first;
	lastName = last;
}

void Person::setFirst(string first) {
	firstName = first;
}

void Person::setLast(string last) {
	lastName = last;
}

string Person::getFirstName() {
	return firstName;
}

string Person::getLastName() {
	return lastName;
}

istream& operator >>(istream& in, Person& p) {
	cout << "Enter firstname lastname: ";
	in >> p.firstName >> p.lastName;
	return in;
}


ostream& operator<<(ostream& out, Person& p) {
	out << p.getFullName();
	return out;
}