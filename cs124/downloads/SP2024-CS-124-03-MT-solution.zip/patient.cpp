#include <iostream>
#include <istream>
#include <iomanip>
#include <string>
#include "patient.h"
#include "person.h"

using namespace std;

Patient::Patient(int patientId, string first, string last, int age)
	: Person(patientId, first, last) {
	this->age = age;
}

int Patient::getAge() {
	return age;
}

void Patient::header() {
	cout << setw(5) << left << "Id"
		<< setw(20) << "Name"
		<< setw(10) << "DOB"
		<< setw(5) << "Age"
		<< setw(15) << "Admit"
		<< setw(15) << "Discharge"
		<< setw(20) << "Doctor" 
		<< setw(10) << "Speciality"
		<< endl;
}

void Patient::print() {

}

Patient& Patient::operator=(Patient& p) {
	this->firstName = p.firstName;
	this->lastName = p.lastName;
	this->id = p.id;
	//this->age = p.age;
	this->dateOfBirth = p.dateOfBirth;
	this->admitDate = p.admitDate;
	this->dischargeDate = p.dischargeDate;
	this->attendingPhysician = p.attendingPhysician;
	return *this;
}

istream& operator>>(istream& in, Patient& p) {
	in >> static_cast<Person&>(p);

	cout << "Enter DOB: ";
	in >> p.dateOfBirth;

	cout << "Enter admit date: ";
	in >> p.admitDate;

	cout << "Enter discharge date: ";
	in >> p.dischargeDate;
	
	in >> p.attendingPhysician;
	return in;
}

ostream& operator<<(ostream& out, Patient& p) {
	out << left << setw(5) << p.id
		<< setw(20) << p.getFullName()
		<< setw(10) << p.dateOfBirth.toDateString()
		<< setw(5) << 2024 - p.dateOfBirth.getYear()
		<< setw(15) << p.admitDate.toDateString()
		<< setw(15) << p.dischargeDate.toDateString()
		<< setw(20) << p.attendingPhysician.getFullName()
		<< setw(10) << p.attendingPhysician.getSpeciality();
	return out;
}
