/**
* Name: <your name>
* Description: provide a short description of this class
* Date: <2/10/2024>
*/

#pragma once
#include <istream>
#include <string>
#include "time.h"

using namespace std;


class DateTime : public Time {
	friend ostream& operator<<(ostream& out, DateTime& dt);
	friend istream& operator >>(istream& in, DateTime& dt);

public:
	DateTime();
	DateTime(string dt);
	DateTime(int mon, int day, int yr);
	DateTime(int mon, int day, int yr, int hr, int min, int second);

	void setDateTime(string dt);

	void setMonth(int _month) { month = _month; };
	void setDay(int _day) { day = _day; };
	void setYear(int _year) { year = _year; };

	int getMonth() { return month; };
	int getDay() { return day; };
	int getYear() { return year; };

	string toString();
	string toDateString();

	// You may need these operators for comparing datetime
	bool operator>(const DateTime&) const;
	bool operator<(const DateTime&) const;
	bool operator>=(const DateTime&) const;
	bool operator<=(const DateTime&) const;
	bool operator==(const DateTime&) const;

	DateTime& operator=(DateTime&);

private:
	int month;
	int day;
	int year;
};
