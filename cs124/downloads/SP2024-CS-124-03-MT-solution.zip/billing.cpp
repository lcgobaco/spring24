#include <iostream>
#include <iomanip>
#include "billing.h"

using namespace std;
Billing::Billing() {
	id = -1;
	pharmacyCharges = 0;
	roomRent = 0;
	doctorFee = 0;
}

// constructor
Billing::Billing(int id, double charges, double rent, double doctorFee) {
	this->id = id;
	pharmacyCharges = charges;
	roomRent = rent;
	this->doctorFee = doctorFee;
}

void Billing::setId(int id)
{
	this->id = id;
}

void Billing::setPharmacy(double p) {
	pharmacyCharges = p;
}


void Billing::setRent(double rent) {
	roomRent = rent;
}

void Billing::setDoctorFee(double d) {
	doctorFee = d;
}

istream& operator >>(istream& in, Billing& b) {
	cout << "Enter patient Id: ";
	in >> b.id;

	cout << "Enter pharmacy charges: $";
	in >> b.pharmacyCharges;

	cout << "Enter rent charges: $";
	in >> b.roomRent;

	cout << "Enter doctor's fee: $";
	in >> b.doctorFee;

	return in;
}

ostream& operator<<(ostream& out, Billing& b) {
	double hospitalCharges = b.pharmacyCharges + b.roomRent + b.doctorFee;
	out << setw(5) << left << to_string(b.id)
		<< setw(5) << to_string(b.pharmacyCharges)
		<< setw(5) << to_string(b.roomRent)
		<< setw(5) << to_string(b.doctorFee)
		<< setw(5) << to_string(hospitalCharges);
	return out;
}