#include <string>
#include <iomanip>
#include "doctor.h"
#include "person.h"

using namespace std;

Doctor::Doctor() :Person(0, "", "") {
	speciality = "";
}

Doctor::Doctor(string first, string last, string special)
	:Person(-1, first, last) {
	speciality = special;
}

void Doctor::print() {
	cout << *this << endl;
}

istream& operator>>(istream& in, Doctor& d) {
	cout << "Enter doctor firstame and last name: ";
	in >> d.firstName >> d.lastName;
	cout << "Enter doctor speciality: ";
	in >> d.speciality;
	return in;
}

ostream& operator<<(ostream& out, Doctor& d) {
	out << setw(10) << left << d.firstName
		<< setw(10) << d.lastName
		<< setw(10) << d.speciality;
	return out;
}