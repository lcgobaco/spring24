/**
* Name: <your name>
* Description: provide a short description of this class
* Date: <2/10/2024>
*/
#include <iostream>
#include <sstream>
#include <string>
#include <iomanip>
#include "dateTime.h"
#include "time.h"

using namespace std;

/**
* TODO: provide comment here
*/
DateTime::DateTime()
	: Time(0, 0, 0) {
	month = 0;
	day = 0;
	year = 0;
};

DateTime::DateTime(int mon, int day, int yr)
	: Time(0, 0, 0) {
	month = mon;
	this->day = day;
	year = yr;
}
/**
* TODO: provide comment here
*/
DateTime::DateTime(int mon, int day, int yr, int hr, int min, int second)
	: Time(hr, min, second) {
	month = mon;
	this->day = day;
	year = yr;
}

/**
* TODO: provide comment here
*/
DateTime::DateTime(string dt) {
	setDateTime(dt);
}

/**
* Convert string dt to dateTime
* Format: ex. 1/29/2024 18:30:11
*/
void DateTime::setDateTime(string dt) {
	// Split string dt datetime to Date and Time
	int index = static_cast<int>(dt.find(' '));
	string sdate = dt.substr(0, index);	// ex. "1/29/2024"
	istringstream ss(sdate);
	string text;
	getline(ss, text, '/');
	month = stoi(text);
	getline(ss, text, '/');
	day = stoi(text);
	getline(ss, text, '/');
	year = stoi(text);

	string stime = dt.substr(++index);	// ex. "18:30:11"	
	Time::setTime(stime);
}

/**
* TODO: provide comment here
*/
string DateTime::toString() {
	return to_string(month) + "/" + to_string(day) + "/" + to_string(year) + " " + Time::toString();
}

string DateTime::toDateString() {
	return to_string(month) + "/" + to_string(day) + "/" + to_string(year);
}

bool DateTime::operator==(const DateTime& dt) const {
	return (dt.month == this->month && dt.day == this->day && dt.year == this->year)
		&& (dt.hour == this->hour && dt.minute == this->minute && dt.second == this->second);
}

DateTime& DateTime::operator=(DateTime& dt) {
	this->setMonth(dt.month);
	this->setDay(dt.day);
	this->setYear(dt.year);
	this->setHour(dt.getHour());
	this->setMinute(dt.getMinute());
	this->setSecond(dt.getSecond());
	return *this;
}

/**
* TODO: provide comment here
* ex.
* cout << "1/29/2024 18:30:11"
*/
ostream& operator<<(ostream& out, DateTime& dt) {
	char fill = out.fill('0');
	out << setw(2) << dt.getMonth() << '/'
		<< setw(2) << dt.getDay() << '/'
		<< setw(2) << dt.getYear()
		<< " " << dt.getTime();
	out.fill(fill);
	return out;
}

istream& operator >>(istream& in, DateTime& dt) {
	cout << "(mm/dd/yyyy hh:mm:sec): ";
	string s1, s2;
	cin >> s1 >> s2;
	dt.setDateTime(s1 + " " + s2);
	/** OR **
	int tmp;
	cin >> tmp;
	dt.setMonth(tmp);
	cout << "Enter day: ";
	cin >> tmp;
	dt.setDay(tmp);
	cout << "Enter year: ";
	cin >> tmp;
	dt.setYear(tmp);
	cout << "Enter hour: ";
	cin >> tmp;
	dt.setHour(tmp);
	cout << "Enter minute: ";
	cin >> tmp;
	dt.setMinute(tmp);
	cout << "Enter second: ";
	cin >> tmp;
	dt.setSecond(tmp);
	*/

	return in;
}
