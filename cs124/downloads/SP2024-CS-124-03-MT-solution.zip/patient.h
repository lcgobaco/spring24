#ifndef PATIENT_H
#define PATIENT_H
#include <iostream>
#include <istream>
#include "person.h"
#include "dateTime.h"
#include "doctor.h"

using namespace std;

class Patient: public Person {

    friend istream& operator >>(istream& in, Patient& p);
    friend ostream& operator<<(ostream& out, Patient& p);

    public:
        Patient(int patientId = 0, string first = "", string last = "", int age = 0);
        int getAge();
        static void header();
        void print();
        Patient& operator=(Patient& p);

    private:
        int age;
        DateTime dateOfBirth;
        DateTime admitDate;
        DateTime dischargeDate;
        Doctor attendingPhysician;
};

#endif // PATIENT_H
