#include "billingMenu.h"
#include "menu.h"

using namespace std;

BillingMenu::BillingMenu() : Menu("Hospital Billing System") {
	addOption("1) Add Patient");
	addOption("2) Display all Patients");
	addOption("x) Exit");
}

void BillingMenu::activate() {
    char ch = 'x';
    do {
        ch = doMenuOption();
        switch (ch) {
        case '1':
            addPatient();
            break;
        case '2':
            print();
            break;
        case 'x':
            cout << "Bye!" << endl;
            break;
        default:
            continue;
        }
    } while (ch != 'x');
}

void BillingMenu::addPatient() {
    Patient p;
    cin >> p;
    list.add(p);
}

void BillingMenu::print() {
    Patient::header();
    if (list.getCount() > 0) {
        //Patient::header();
        while (!list.isEmpty()) {
            cout << list.front() << endl;
            list.remove();
        }
    }
    else {
        cout << "There is no patient!" << endl;
    }
}