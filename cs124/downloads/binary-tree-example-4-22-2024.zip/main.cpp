/*
   This program demonstrates a decision tree for an animal
   guessing game.
*/

#include <iostream>
#include <string>
#include "binary_tree.h"

using namespace std;
string article(const string& entry)
{
    string article = "a";
    if (string("aeiou").find(entry[0]) != string::npos)
    {
        article =  "an";
    }
    return article;
}
int main()
{
    Binary_tree root(
        Binary_tree("Is it a mammal?",
                    Binary_tree("Does it have stripes?",
                                Binary_tree("Is it a carnivore?",
                                            Binary_tree("tiger"),
                                            Binary_tree("zebra")),
                                Binary_tree("pig.")),
                    Binary_tree("Does it fly?",
                                Binary_tree("eagle"),
                                Binary_tree("Does it swim?",
                                            Binary_tree("penguin"),
                                            Binary_tree("ostrich")))));

    bool done = false;
    Binary_tree question_tree = root;
    while (!done)
    {
        string response;
        Binary_tree left = question_tree.left();
        Binary_tree right = question_tree.right();
        if (left.empty() && right.empty())
        {
            string entry = question_tree.data();
            cout << "Is it " + article(entry) << ' ' << question_tree.data() << " (y/n)? " << endl;

            getline(cin, response);
            if ( toupper(response[0]) == 'Y')
            {
                cout << "I guessed it!" << endl;
            }
            else
            {
                cout << "I give up." << endl;
                cout << "What is it? ";
                getline (cin, response);
                cout << "Please give me a question that is true for "
                     << article(response) << ' ' << response
                     << " but is not true for "
                     << article(entry) << ' ' << entry << ":" << endl;
                string question;
                getline (cin, question);
                question_tree.set(question, Binary_tree(response),
                                  Binary_tree(question_tree.data(), question_tree.left(), question_tree.right()));
            }

            cout << "May I try again? ";
            getline(cin, response);
            if (toupper(response[0]) != 'Y' )
            {
                done = true;
            }
            else
            {
                question_tree = root;
            }
        }
        else
        {
            do
            {
                cout << question_tree.data() << " (y/n): ";
                getline(cin, response);
            }
            while (response != "y" && response != "n");

            if (response == "y")
            {
                question_tree = left;
            }
            else
            {
                question_tree = right;
            }
        }
    }
}



