#include "contactList.h"

void ContactList::sortBy(bool ascending) {
	selectionSort(ascending);
}

void ContactList::print() const {
	
	
	
	
	
	
	// todo
	// loop - iterator
	// cout << iterator->get() // instanceContact 
}