#include <string>
#include <iostream>
#include "contactMenu.h"

using namespace std;

int main() {
    
    ContactMenu menu;
    menu.activate();

    return 0;
}

