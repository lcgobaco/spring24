#include "contactMenu.h"

using namespace std;

void ContactMenu::activate() {
	// todo
}