#pragma once
#include "menu.h"

class ContactMenu : public Menu {

public:
	void activate();
};
