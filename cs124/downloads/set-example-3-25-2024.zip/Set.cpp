#include "Set.h"

class Set_iterator
{
public:
    Set_iterator();
    Set_iterator(list<int>::iterator p);
    void next();
    int get();
    bool equals(Set_iterator other);
private:
    list<int>::iterator pos;
};

Set::Set()
{
}

bool Set::is_element(int x)
{
    list<int>::iterator pos;
    for (pos = items.begin(); pos != items.end(); pos++)
        if (*pos == x)
        {
            return true;
        }
    return false;
}

void Set::insert(int x)
{
    if (!is_element(x))
    {
        items.push_back(x);
    }
}

void Set::erase(int x)
{
    list<int>::iterator pos;
    for (pos = items.begin(); pos != items.end(); pos++)
        if (*pos == x)
        {
            items.erase(pos);
            return;
        }
}

void Set::print()
{
    Set_iterator pos;
    cout << "{ ";
    for (pos = items.begin(); !pos.equals(items.end()); pos.next())
    {
        cout << pos.get() << " ";
    }
    cout << "}\n";
}

Set_iterator Set::begin()
{
    return Set_iterator(items.begin());
}

Set_iterator Set::end()
{
    return Set_iterator(items.end());
}

Set_iterator::Set_iterator()
{
}

Set_iterator::Set_iterator(list<int>::iterator p)
{
    pos = p;
}

void Set_iterator::next()
{
    pos++;
}

int Set_iterator::get()
{
    return *pos;
}

bool Set_iterator::equals(Set_iterator other)
{
    return pos == other.pos;
}

/**
 Constructs a set that is the union of two sets.
 @param a, b - two sets
 @return a new set that is the union of a and b
*/
Set set_union(Set a, Set b)
{
    Set c;

    Set_iterator pos;
    for (pos = a.begin(); !pos.equals(a.end()); pos.next())
    {
        c.insert(pos.get());
    }

    for (pos = b.begin(); !pos.equals(b.end()); pos.next())
    {
        c.insert(pos.get());
    }

    return c;
}

/**
 Constructs a set that is the intersection of two sets.
 @param a, b - two sets
 @return a new set that is the intersection of a and b
*/
Set intersection(Set a, Set b)
{
    Set c;
    Set_iterator pos;

    for (pos = a.begin(); !pos.equals(a.end()); pos.next())
        if (b.is_element(pos.get()))
        {
            c.insert(pos.get());
        }

    return c;
}



