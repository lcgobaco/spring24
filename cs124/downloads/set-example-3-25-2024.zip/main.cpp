#include "Set.h"
Set set_union(Set a, Set b);
Set intersection(Set a, Set b);

int main()
{
    Set s;
    s.insert(3);
    s.insert(4);
    s.insert(5);

    cout << "The first set contains: ";
    s.print();

    Set t;
    t.insert(1);
    t.insert(2);
    t.insert(3);

    cout << "The second set contains: ";
    t.print();

    Set u = set_union(s, t);
    Set v = intersection(s, t);

    cout << "The union of the two sets is: ";
    u.print();

    cout << "The intersection of the two sets is: ";
    v.print();
}




