#include <iostream>
#include <list>

using namespace std;

class Set_iterator;

class Set
{
public:
    Set();
    bool is_element(int x);
    void insert(int x);
    void erase(int x);
    void print();
    Set_iterator begin();
    Set_iterator end();
private:
    list<int> items;
};


