#include "course.h"
#include <string>

using namespace std;

string Course::sortByField = FIELD_DEPT;

Course& Course::operator=(const Course& c) {
	this->department = c.department;
	// todo
	return *this;
}

bool Course::operator==(const Course& c) {
	// TODO
	bool value;
	value = this->department == c.department;

	return value;
}
bool Course::operator>(const Course& c) {
	bool v = true;
	if (sortByField == FIELD_DEPT) {
		v = this->department > c.department;
	}
	else if (sortByField == FIELD_COURSE_NO) {
		// todo
	}
	else if (sortByField == FIELD_TITLE) {
		// todo
	}
	else if (sortByField == FIELD_DESCR) {
		// todo
	}
	else if (sortByField == FIELD_PREREQ) {
		// todo
	}
	else if (sortByField == FIELD_UNITS) {
		// todo
	}

	return v;
}