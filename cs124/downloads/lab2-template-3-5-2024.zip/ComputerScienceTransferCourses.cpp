#include "computerScienceTransferCourses.h"

using namespace std;

void ComputerScienceTransferCourses::sortBy(bool ascending) {
	quickSort(ascending);
}

void ComputerScienceTransferCourses::print() const {
	// todo
}