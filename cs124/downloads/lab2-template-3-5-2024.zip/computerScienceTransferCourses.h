#pragma once
#include "unorderedArrayList.h"
#include "course.h"
#include "arrayList.h"

class ComputerScienceTransferCourses : public UnorderedArrayList<Course> {

public:
	void sortBy(bool ascending = true);
	void print() const;
};