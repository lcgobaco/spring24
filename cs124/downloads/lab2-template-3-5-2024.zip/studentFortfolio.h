#pragma once
#include <fstream>
#include "menu.h"
#include "computerScienceTransferCourses.h"

const string DATA_FILE = "cs_transfer_courses.dat";

class StudentFortfolio : public Menu {
public:
	StudentFortfolio();

	void activate();

private:
	fstream inFile;			// file pointer

	void initSelection();
	void initData();
	ComputerScienceTransferCourses* pTransferCourses;
};