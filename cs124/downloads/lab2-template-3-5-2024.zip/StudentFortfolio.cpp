#include "studentFortfolio.h"
#include "course.h"
#include "utils.h"
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

StudentFortfolio::StudentFortfolio() : Menu("Computer Science Transfer Courses") {
    pTransferCourses = new ComputerScienceTransferCourses();

    // init usermenu options
    initSelection();
    // load users_data.csv
    initData();
}

void StudentFortfolio::initSelection() {
    // Initialize users options
    addOption("1) List of courses");
    addOption("2) View the course details");
    addOption("3) Add a new course");
    addOption("4) Edit course");
    addOption("5) Remove course");
    addOption("x) Quit");
}

void StudentFortfolio::initData() {
    openFile(inFile, DATA_FILE);

    string line = ""; //this is where the current line in the csv is saved to
    while (getline(inFile, line)) {
        stringstream ss(line);
        Course c;
        // todo
        pTransferCourses->insert(c);
    }
}

void StudentFortfolio::activate() {
	char input = 0;
	do {
		input = this->doMenuOption();
		// todo
	} while (input != 'x');
}
