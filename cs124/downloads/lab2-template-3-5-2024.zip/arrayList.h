#ifndef H_ARRAYLISTTYPE
#define H_ARRAYLISTTYPE

#include <iostream>

const int DEFAULT_ARRAY_SIZE = 100;

using namespace std;

template <typename T>
class ArrayList {
public:
    //Constructor
    //Creates an array of the size specified by the 
    //parameter size. The default array size is 100.
    //Postcondition: The list points to the array, length = 0,
    //               and maxLength = size;
    ArrayList(int size = DEFAULT_ARRAY_SIZE);

    //Copy constructor
    ArrayList(const ArrayList<T>& other);

    //Destructor
    virtual ~ArrayList();

    //Function to determine whether the list is empty
    //Postcondition: Returns true if the list is empty;
    //               otherwise, returns false.
    bool isEmpty() const;

    //Function to determine whether the list is full
    //Postcondition: Returns true if the list is full; 
    //               otherwise, returns false.
    bool isFull() const;

    //Function to determine the number of elements in 
    //the list.
    //Postcondition: Returns the value of length.
    int size() const;

    //Function to determine the maximum size of the list
    //Postcondition: Returns the value of maxLength.
    int maxSize() const;

    //Function to output the elements of the list
    //Postcondition: Elements of the list are output on the 
    //               standard output device.
    void print() const;

    //Function to determine whether item is the same as
    //the item in the list at the position specified 
    //by location.
    //Postcondition: Returns true if the list[location] 
    //               is the same as item; otherwise, 
    //               returns false.
    //               If location is out of range, an 
    //               appropriate message is displayed.
    bool equal(int location, const T& item) const;

    //Function to insert insertItem an item at the end of 
    //the list. Note that this is an abstract function.
    //Postcondition: list[length] = insertItem; and length++;
    //               If the list is full, an appropriate 
    //               message is displayed.
    virtual void insert(const T& insertItem) = 0;

    void prepend(T newItem);

    //Function to remove the item from the list at the 
    //position specified by location 
    //Postcondition: The list element at list[location] is 
    //               removed and length is decremented by 1.
    //               If location is out of range, an 
    //               appropriate message is displayed.
    void removeAt(int location);

    //Function to retrieve the element from the list at the  
    //position specified by location 
    //Postcondition: retItem = list[location] 
    //               If location is out of range, an 
    //               appropriate message is displayed.
    void retrieveAt(int location, T& retItem) const;

    //Function to replace repItem the elements in the list 
    //at the position specified by location. 
    //Note that this is an abstract function.
    //Postcondition: list[location] = repItem 
    //               If location is out of range, an 
    //               appropriate message is displayed.
    virtual void replaceAt(int location, const T& repItem) = 0;

    //Function to remove all the elements from the list 
    //After this operation, the size of the list is zero.
    //Postcondition: length = 0;
    void clear();

    //Function to search the list for searchItem.
    //Note that this is an abstract function.
    //Postcondition: If the item is found, returns the 
    //               location in the array where the item is  
    //               found; otherwise, returns -1.
    virtual int search(const T& searchItem) const;

    //Function to remove removeItem from the list.
    //Note that this is an abstract function.
    //Postcondition: If removeItem is found in the list,
    //               it is removed from the list and length 
    //               is decremented by one.
    virtual void remove(const T& removeItem) = 0;

    void resize(int newAllocationSize);

    //Overloads the assignment operator
    const ArrayList<T>& operator=(const ArrayList<T>&);

protected:
    T* list;            //array to hold the list elements
    int length;         //variable to store the length of the list
    int maxLength;      //variable to store the maximum size of the list
};

template <typename T>
ArrayList<T>::ArrayList(int size) {
    if (size <= 0) {
        cout << "The array size must be positive. Creating "
            << "an array of the size 100. " << endl;
        maxLength = DEFAULT_ARRAY_SIZE;
    }
    else
        maxLength = size;

    length = 0;

    list = new T[maxLength];
}

template <typename T>
ArrayList<T>::ArrayList(const ArrayList<T>& other)
{
    maxLength = other.maxLength;
    length = other.length;

    list = new T[maxLength]; 	        //create the array

    for (int j = 0; j < length; j++) {  //copy otherList
        list[j] = other.list[j];
    }
}//end copy constructor


template <typename T>
ArrayList<T>::~ArrayList() {
    delete[] list;
}

template <typename T>
bool ArrayList<T>::isEmpty() const {
    return (length == 0);
}

template <typename T>
bool ArrayList<T>::isFull() const {
    return (length == maxLength);
}

template <typename T>
int ArrayList<T>::size() const {
    return length;
}

template <typename T>
int ArrayList<T>::maxSize() const {
    return maxLength;
}

template <typename T>
void ArrayList<T>::print() const {
    for (int i = 0; i < length; i++) {
        cout << list[i] << " ";
    }
    cout << endl;
}

template <typename T>
bool ArrayList<T>::equal(int location, const T& item)  const {
    if (location < 0 || location >= length) {
        cout << "The location of the item to be removed "
            << "is out of range." << endl;
        return false;
    }
    else
        return (list[location] == item);
}

template <typename T>
void ArrayList<T>::removeAt(int location) {
    if (location < 0 || location >= length) {
        cout << "The location of the item to be removed "
            << "is out of range." << endl;
    }
    else {
        for (int i = location; i < length - 1; i++) {
            list[i] = list[i + 1];
        }

        length--;
    }
} //end removeAt

template <typename T>
void ArrayList<T>::retrieveAt(int location, T& retItem) const {
    if (location < 0 || location >= length) {
        cout << "The location of the item to be retrieved is "
                << "out of range" << endl;
    }
    else
        retItem = list[location];
} //end retrieveAt

template <typename T>
void ArrayList<T>::clear() {
    length = 0;
} //end clear

template <typename T>
const ArrayList<T>& ArrayList<T>::operator= (const ArrayList<T>& otherList) {
    if (this != &otherList) {   //avoid self-assignment
        delete[] list;
        maxLength = otherList.maxLength;
        length = otherList.length;

        list = new T[maxLength];

        for (int i = 0; i < length; i++) {
            list[i] = otherList.list[i];
        }
    }
    return *this;
}

template <typename T>
void ArrayList<T>::resize(int newAllocationSize) {
    // Create a new array with the indicated size
    T* newArray = new T[newAllocationSize];

    // Copy items in current array into the new array
    for (int i = 0; i < length; ++i) {
        newArray[i] = list[i];
    }

    // Free current array
    delete[] list;

    // Assign the arrayData member with the new array
    list = newArray;

    // Update allocation size
    maxLength = newAllocationSize;
}

template <typename T>
void ArrayList<T>::prepend(T newItem) {
    // Resize if the array is full
    if (isFull()) {
        resize(maxLength * 2);
    }

    // Shift all array items to the right,
    // starting from the last index and moving 
    // down to the first index.
    for (int i = length; i > 0; --i) {
        list[i] = list[i - 1];
    }

    // Insert the new item at index 0
    list[0] = newItem;

    // Increment arrayListLength to reflect the added item
    ++length;
}

template <typename T>
int ArrayList<T>::search(const T& searchItem) const {
    int loc;
    bool found = false;
    loc = 0;

    while (loc < this->length && !found) {
        if (this->list[loc] == searchItem) {
            found = true;
        }
        else {
            loc++;
        }
    }

    if (found) {
        return loc;
    }
    else {
        return -1;
    }
} //end search

#endif