#pragma once
#include <string>
#include <fstream>

using namespace std;
/**
* Get system time
*/
void getCurrentTime(int& mo, int& d, int& yr, int& hr, int& min, int& sec);

void openFile(fstream& inFile, string fileName);