#pragma once
#include <string>

using namespace std;

const string FIELD_DEPT = "Department";
const string FIELD_COURSE_NO = "Course Number";
const string FIELD_TITLE = "Title";
const string FIELD_DESCR = "Description";
const string FIELD_PREREQ = "Prerequisite";
const string FIELD_UNITS = "Units";

class Course {
public:
	void setSortByField(string name) {
		sortByField = name;
	};

	Course& operator=(const Course&);

	bool operator==(const Course&);
	bool operator>(const Course&);
	bool operator<(Course&);

private:
	static string sortByField;
	string department;	//department(ex.CS)
	string courseNo;	//course number(ex. 101)
	string title;		//course title
	string description;	//multiple lines of description
						//The ending backslash "\" is a special character that indicates the continuation of the next line.
	string prereq;		//ex. ENGL 151B
	int units;			//integer value for units 
};