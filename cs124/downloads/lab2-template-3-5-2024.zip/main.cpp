#include <iostream> 
#include "studentFortfolio.h"

using namespace std;

int main() {
	StudentFortfolio app;
	app.activate();
    return 0;
}