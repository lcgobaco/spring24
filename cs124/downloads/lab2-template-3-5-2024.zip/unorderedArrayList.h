#ifndef H_UNORDEREDARRAYLISTTYPE
#define H_UNORDEREDARRAYLISTTYPE

#include <iostream>
#include "arrayList.h"

using namespace std;

template <typename T>
class UnorderedArrayList : public ArrayList<T> {
public:
    //Constructor
    UnorderedArrayList();

    void insert(const T& insertItem);
    void replaceAt(int location, const T& repItem);
    void remove(const T& removeItem);
    int search(const T& searchItem);

protected:
    void quickSort(bool ascending);

private:
    bool sorted;    // true for sorted

    // QuickSort 
    void swap(T list[], int first, int second);
    int partition(T list[], int first, int last);
    void recQuickSort(T list[], int first, int last, bool ascending);


    // Binary search
    int binarySearch(const T& item);
};

template <typename T>
UnorderedArrayList<T>::UnorderedArrayList()
    : ArrayList<T>(DEFAULT_ARRAY_SIZE) {
    sorted = false;
}

template <typename T>
void UnorderedArrayList<T>::insert(const T& insertItem) {
    if (this->length >= this->maxLength) { //the list is full
        cout << "Cannot insert in a full list." << endl;
    } else {
        this->list[this->length] = insertItem; //insert the item at the end
        this->length++; //increment the length
    }
} //end insertEnd

template <typename T>
void UnorderedArrayList<T>::remove(const T& removeItem) {
    int loc;

    if (this->length == 0) {
        cout << "Cannot delete from an empty list." << endl;
    } else {
        loc = search(removeItem);
        if (loc != -1) {
            this->removeAt(loc);
        }
        else {
            cout << "The tem to be deleted is not in the list." << endl;
        }
    }
} //end remove

template <typename T>
void UnorderedArrayList<T>::replaceAt(int location, const T& repItem) {
    if (location < 0 || location >= this->length) {
        cout << "The location of the item to be "
            << "replaced is out of range." << endl;
    }
    else {
        this->list[location] = repItem;
    }
} //end replaceAt

template <typename T>
void UnorderedArrayList<T>::swap(T list[],int first, int second) {
    T temp;

    temp = list[first];
    list[first] = list[second];
    list[second] = temp;
} //end swap

template <typename T>
int UnorderedArrayList<T>::partition(T list[], int first, int last) {
    T pivot;
    int index, smallIndex;
    swap(list, first, (first + last) / 2);

    pivot = list[first];
    smallIndex = first;

    for (index = first + 1; index <= last; index++) {
        if (list[index] > pivot) {
            smallIndex++;
            swap(list, smallIndex, index);
        }
    }

    swap(list, first, smallIndex);

    return smallIndex;
} //end partition

template <typename T>
void UnorderedArrayList<T>::recQuickSort(T list[], int first, int last, bool ascending) {
    int pivotLocation;
    if (first < last) {
        pivotLocation = partition(list, first, last);
        recQuickSort(list, first, pivotLocation - 1, ascending);
        recQuickSort(list, pivotLocation + 1, last, ascending);
    }
} //end recQuickSort

template <typename T>
void UnorderedArrayList<T>::quickSort(bool ascending) {
    recQuickSort(this->list, 0, this->length - 1, ascending);
    sorted = true;
} //end quickSort

template <typename T>
int UnorderedArrayList<T>::search(const T& searchItem) {
    return (!sorted)
            ? ArrayList<T>::search(searchItem)
            : binarySearch(searchItem);
} //end search

template <typename T>
int UnorderedArrayList<T>::binarySearch(const T& item) {
    int first = 0;
    int last = this->length - 1;
    int mid;

    bool found = false;

    while (first <= last && !found) {
        mid = (first + last) / 2;

        if (this->list[mid] == item) {
            found = true;
        }
        else if (this->list[mid] > item) {
            last = mid - 1;
        }
        else {
            first = mid + 1;
        }
    }

    if (found)
        return mid;
    else
        return -1; // not found
} //end binarySearch

#endif