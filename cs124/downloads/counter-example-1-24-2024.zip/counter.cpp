#include "counter.h"

using namespace std;

Counter::Counter() {
    // default constructor
    value = 0;
}

Counter::~Counter(){
    // destructutor
}
    
// method of the class - act on the class counter
void Counter::reset() {
    value = 0;
}

void Counter::count() {
    value = value + 1;
    //value++;
    //++value;
    //value +=1;
}
   
// Mutator method
void Counter::setValue(int value) {
    this->value = value;
}
   
// Accessor method
int Counter::getValue() const {
    return value;
}
