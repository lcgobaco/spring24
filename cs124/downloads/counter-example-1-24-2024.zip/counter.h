using namespace std;

class Counter {
public:
    Counter();  // default constructor
    ~Counter(); // destructutor
    
    // method of the class - act on the class counter
    void reset();
    void count();
       
    // Mutator method
    void setValue(int value);
       
    // Accessor method
    int getValue() const;
   
private:
   int value;
};