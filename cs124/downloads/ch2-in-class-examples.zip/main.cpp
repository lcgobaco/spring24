#include "dateTime.h"

int main() {
	DateTime dt(1, 29, 2024, 7, 30, 0);
	DateTime dt2("01/29/2024 HH:MM:SEC");

	dt.toString();

	return 0;
}