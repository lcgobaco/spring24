#pragma once
class Date {
private:
	int mon, day, year;
};