#pragma once
#include "time.h"
#include "date.h"

class MyDate {

private:
	Date d;
	Time t;
};
