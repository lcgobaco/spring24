//Test Program linked queue

#include <iostream>
#include "linkedQueue.h"
  
using namespace std; 
 
int main() {
    LinkedQueue<int> queue1, queue2;
    int x, y;

    x = 4;
    y = 5;
    queue1.add(x);
    queue1.add(y);
    x = queue1.front();
    queue1.remove();
    queue1.add(x + 5);
    queue1.add(16);
    queue1.add(x);
    queue1.add(y - 3);

    queue2 = queue1;

    cout << "queue1: ";

    while (!queue1.isEmpty())
    {
        cout << queue1.front() << " ";
        queue1.remove();
    }
 
    cout << endl;

    cout << "queue2: ";

    while (!queue2.isEmpty())
    {
        cout << queue2.front() << " ";
        queue2.remove();
    }

    cout << endl;

    return 0;
}